package com.app.nychighschools

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.app.nychighschools.data.SchoolResponseItem
import com.app.nychighschools.ui.theme.NYCHighSchoolsTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    val viewModel: SchoolViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.dataResult.observe(this) {
            it?.let {
                setContent {
                    NYCHighSchoolsTheme {
                        // A surface container using the 'background' color from the theme
                        Surface(
                            modifier = Modifier.fillMaxSize(),
                            color = MaterialTheme.colorScheme.background
                        ) {
                            ListScreen(it)
                        }
                    }
                }
            }
        }

    }
}

@Composable
fun ListScreen(listItem: List<SchoolResponseItem>) {
    var show by remember { mutableStateOf(false) }
    var itemvalue by remember {
        mutableStateOf("")
    }
    Column(modifier = Modifier.fillMaxSize()) {
        Text(text = "School List")
        Spacer(modifier = Modifier.height(2.dp))
        LazyColumn {
            items(listItem) { item ->
                ListItem(item = item) {
                    show = true
                    itemvalue = item.overview_paragraph
                }
            }
        }
    }
    if (show) {
        ViewPage(data = itemvalue, onDismiss = { show = false })
    }

}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListItem(item: SchoolResponseItem, onItemClick: () -> Unit) {
    Card(onClick = onItemClick) {
        Column {
            Text(text = item.school_name, style = TextStyle(color = Color.Green))
            Text(text = item.dbn)
        }
    }
}

@Composable
fun ViewPage(data: String, onDismiss: () -> Unit) {
    Dialog(
        onDismissRequest = { onDismiss },
        properties = DialogProperties(dismissOnBackPress = true, dismissOnClickOutside = true)
    ) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Box(modifier = Modifier.fillMaxSize()) {
                Text(text = data, modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}