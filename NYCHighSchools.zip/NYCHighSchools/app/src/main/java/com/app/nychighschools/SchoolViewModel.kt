package com.app.nychighschools

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.app.nychighschools.data.SchoolResponse
import com.app.nychighschools.data.repository.SchoolRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SchoolViewModel @Inject constructor(val repository: SchoolRepository): ViewModel(){
    private var _dataResult = MutableLiveData<SchoolResponse?>(null)
    val dataResult: LiveData<SchoolResponse?> = _dataResult

    init {
        getData()
    }

    private fun getData() {
        viewModelScope.launch {
            val response = repository.getList()
            if (response.isSuccessful){
                response.body()?.let {
                    _dataResult.value = it
                }?: run { println("Error Response") }
            }else println("Error ${response.message()}")
        }
    }
}