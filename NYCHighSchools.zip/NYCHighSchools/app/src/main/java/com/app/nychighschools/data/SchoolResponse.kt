package com.app.nychighschools.data

class SchoolResponse : ArrayList<SchoolResponseItem>()