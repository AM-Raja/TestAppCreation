package com.app.nychighschools.data

data class SchoolResponseItem(
    val school_name: String, val dbn: String, val overview_paragraph: String
)