package com.app.nychighschools.data.repository

import com.app.nychighschools.data.SchoolResponse
import com.app.nychighschools.data.services.APIservice
import retrofit2.Response
import javax.inject.Inject

class SchoolRepository @Inject constructor(val api: APIservice) {

    suspend fun getList(): Response<SchoolResponse>{
        return api.getList()
    }

}