package com.app.nychighschools.data.services

import com.app.nychighschools.data.SchoolResponse
import retrofit2.Response
import retrofit2.http.GET

interface APIservice {
    @GET("s3k6-pzi2.json")
    suspend fun getList(): Response<SchoolResponse>
}